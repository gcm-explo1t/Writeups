#!/usr/bin/env python3
import argparse
import sys
import signal
import socket
import threading
import time
from hashlib import md5

def exithandler(signal, frame):
    try:
        if limeSDRdata is not None:
            limeSDRdata.close()
        if local_stream is not None:
            local_stream.close()
    except:
     pass
    sys.exit(0)

def pingServer():
    while True:
        client_socket.sendto(b'ping', ADDR)
        time.sleep(1)

def acceptClient():
    global got_Accepted
    message, address = client_socket.recvfrom(1024)
    if message == b'authenticated':
        print("Successfully connected")
        got_Accepted = True

def authClient():
    global got_Challenge
    got_challenge_response = False
    message, address = client_socket.recvfrom(1024)
    if len(message) == 32:
        print("Got Challenge")
        got_Challenge = True
        challenge = bytes(md5(message).hexdigest(),"utf-8")
        clientAccept = threading.Thread(target=acceptClient)
        clientAccept.start()
        while not got_Accepted:
            client_socket.sendto(challenge, ADDR)
            time.sleep(0.1)

signal.signal(signal.SIGINT, exithandler)
parser = argparse.ArgumentParser(description='Creates connection for the garage challenge')
parser.add_argument('-f', '--file', dest='filename',default=None, help="Write Stream to file")
args = parser.parse_args()

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
ADDR = ("hax.allesctf.net", 4242)

clientAuth = threading.Thread(target=authClient)
clientAuth.start()

got_Challenge = False
got_Accepted = False

while not got_Challenge:
    client_socket.sendto(b'auth', ADDR)
    time.sleep(0.1)
clientAuth.join()

serverPing = threading.Thread(target=pingServer)
serverPing.start()


## FROM HERE ON THE UDP SOCKET IS OPEN AND CAN BE USED AS YOU LIKE CURRENTLY IT IS FORWARDED VIA A TCP STREAM

if args.filename:
    limeSDRdata = open(args.filename,"wb")
    print("Writing Data into",args.filename)
    while True:
        message, address = client_socket.recvfrom(1024)
        limeSDRdata.write(message)
else:
    HOST = '127.0.0.1'
    PORT = 1234
    local_stream = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    local_stream.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    try:
            local_stream.bind((HOST, PORT))
    except socket.error as msg:
            sys.exit(0)

    local_stream.listen(10)
    print("Waiting for local stream Reader")
    conn, addr = local_stream.accept()
    print("Streamreader connected")

    while True:
        message, address = client_socket.recvfrom(1024)
        conn.send(message)
